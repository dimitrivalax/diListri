# Item Create

The news feed adde Page creates new instances of `news `. All the fields are required in this scenario . 
