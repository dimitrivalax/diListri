# Followers

The followers  page is a component from ionic where there are sliding animation from angular and follow back option is available .
