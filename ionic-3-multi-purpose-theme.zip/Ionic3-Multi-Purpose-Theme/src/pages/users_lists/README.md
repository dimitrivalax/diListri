# Cards

The page is having all the user lists where we have used the default component of ionic and added some custome css on the top of it . 
