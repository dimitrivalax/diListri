# Menu

The profile  page contains user details where option to move to follower and following pages .Edit , cancel and save operations are done . 
