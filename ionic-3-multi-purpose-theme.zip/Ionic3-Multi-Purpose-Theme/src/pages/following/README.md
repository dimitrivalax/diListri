# Followings

The following   page is a component from ionic where there are sliding animation from angular and unfollow option is available .
