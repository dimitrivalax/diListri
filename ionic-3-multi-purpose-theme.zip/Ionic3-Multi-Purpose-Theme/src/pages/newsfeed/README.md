# Cards

The News feed page is a common cards-based layout of ionic  as seen in such apps as Facebook.
